const startButton = document.getElementById("startButton");
const cvForm = document.getElementById("cvForm");
const jobButton = document.getElementById("jobButton");
const editCVButton = document.getElementById("editCVButton");
const downloadButton = document.getElementById("downloadButton");

// Homepage button
if (startButton) {
    startButton.addEventListener("click", function () {
        window.location.href = "cv-form.html";
    });
}

// CV form submission
if (cvForm) {
    cvForm.addEventListener("submit", function (event) {
        event.preventDefault();

        const cvData = {
            fullName: document.getElementById("fullName").value,
            email: document.getElementById("email").value,
            phone: document.getElementById("phone").value,
            education: document.getElementById("education").value,
            skills: document.getElementById("skills").value,
            experience: document.getElementById("experience").value,
            sector: document.getElementById("sector").value
        };

        localStorage.setItem("cvData", JSON.stringify(cvData));

        window.location.href = "cv-preview.html";
    });
}

// Display CV information on preview page
const savedCVData = localStorage.getItem("cvData");

if (savedCVData) {
    const cvData = JSON.parse(savedCVData);

    const previewName = document.getElementById("previewName");

    if (previewName) {
        previewName.textContent = cvData.fullName;
        document.getElementById("previewEmail").textContent = cvData.email;
        document.getElementById("previewPhone").textContent = cvData.phone;
        document.getElementById("previewEducation").textContent = cvData.education;
        document.getElementById("previewSkills").textContent = cvData.skills;
        document.getElementById("previewExperience").textContent = cvData.experience;
        document.getElementById("previewSector").textContent = cvData.sector;
    }
}

// Job recommendation button
if (jobButton) {
    jobButton.addEventListener("click", function () {
        window.location.href = "job-recommendations.html";
    });
}


const recommendationMessage = document.getElementById("recommendationMessage");
const jobList = document.getElementById("jobList");
const backToCVButton = document.getElementById("backToCVButton");

if (recommendationMessage && jobList) {
    const savedCVData = localStorage.getItem("cvData");

    if (savedCVData) {
        const cvData = JSON.parse(savedCVData);

        const jobRecommendations = {
            "Information Technology": [
                "Junior Web Developer",
                "IT Support Technician",
                "Software Developer Intern"
            ],
            "Education": [
                "Teacher Assistant",
                "Tutor",
                "Education Administrator"
            ],
            "Finance": [
                "Junior Financial Assistant",
                "Bookkeeper",
                "Accounts Clerk"
            ],
            "Health": [
                "Healthcare Assistant",
                "Medical Receptionist",
                "Community Health Worker"
            ],
            "Engineering": [
                "Junior Engineering Technician",
                "CAD Assistant",
                "Engineering Intern"
            ],
            "Marketing": [
                "Social Media Assistant",
                "Marketing Intern",
                "Content Creator"
            ]
        };

        const recommendedJobs = jobRecommendations[cvData.sector];

        recommendationMessage.textContent =
            "Here are job roles that may match your selected sector: " + cvData.sector;

        if (recommendedJobs) {
            recommendedJobs.forEach(function (job) {
                const jobCard = document.createElement("article");
                jobCard.classList.add("job-card");

                jobCard.innerHTML = `
                    <h3>${job}</h3>
                    <p>This role may suit someone interested in ${cvData.sector}.</p>
                `;

                jobList.appendChild(jobCard);
            });
        } else {
            jobList.innerHTML = "<p>No job recommendations are available yet.</p>";
        }
    } else {
        recommendationMessage.textContent =
            "No CV information was found. Please create your CV first.";
    }
}

if (backToCVButton) {
    backToCVButton.addEventListener("click", function () {
        window.location.href = "cv-preview.html";
    });
}


if (editCVButton) {
    editCVButton.addEventListener("click", function () {
        window.location.href = "cv-form.html";
    });
}


if (cvForm) {
    const savedCVData = localStorage.getItem("cvData");

    if (savedCVData) {
        const cvData = JSON.parse(savedCVData);

        document.getElementById("fullName").value = cvData.fullName;
        document.getElementById("email").value = cvData.email;
        document.getElementById("phone").value = cvData.phone;
        document.getElementById("education").value = cvData.education;
        document.getElementById("skills").value = cvData.skills;
        document.getElementById("experience").value = cvData.experience;
        document.getElementById("sector").value = cvData.sector;
    }
}


if (downloadButton) {
    downloadButton.addEventListener("click", function () {
        const cvPreview = document.querySelector(".cv-preview-card");

        const options = {
            margin: 10,
            filename: "my-cv.pdf",
            image: { type: "jpeg", quality: 0.98 },
            html2canvas: { scale: 2 },
            jsPDF: { unit: "mm", format: "a4", orientation: "portrait" }
        };

        html2pdf().set(options).from(cvPreview).save();
    });
}